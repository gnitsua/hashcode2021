from Input import Input

if __name__ == "__main__":
    input = Input.parse("a.txt")

    print(input)